package pkg1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String user = request.getParameter("login_user");
		String pass = request.getParameter("login_pass");
		
		if (user.equals("admin") && pass.equals("admin@123")) {
			out.println("Login Successfull!");
		}
		else {
			out.println("Error : Invalid User Name or Password!");
		}
		out.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String user = request.getParameter("login_user");
		String pass = request.getParameter("login_pass");
		
		if (user.equals("admin") && pass.equals("admin@123")) {
			out.println("Login Successfull!");
		}
		else {
			out.println("Error : Invalid User Name or Password!");
		}
		out.close();
	}
}